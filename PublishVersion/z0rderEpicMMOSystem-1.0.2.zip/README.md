# Description:

This is fork of WackyEpicMMOSystem https://valheim.thunderstore.io/package/WackyMole/WackyEpicMMOSystem/ for private server [LootGoblinsInc]

Mods:
- Hardcore config to reset character level on death